﻿namespace SampleProject { public class Calculator { public int Add(int a, int b) => a + b; } }
